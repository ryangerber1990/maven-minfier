if (window.location.href.indexOf('checkout') > -1) {
    window.onload = function() {
        var autoCompleteSet = false;
        var stylesAdded = false;
        var suburbSearch = document.getElementById('checkout_shipping_address_address2');
        if (suburbSearch != null) {
            suburbSearch.onchange = function() {

                populateFields()
            };

            suburbSearch.onkeyup = function() {
               
                    if (suburbSearch.value.length > 2) {
                        var xmlhttp = new XMLHttpRequest();
                        xmlhttp.onreadystatechange = function() {
                            if (xmlhttp.readyState == XMLHttpRequest.DONE) {
                                if (xmlhttp.status == 200) {
                                   try {
                                    var dataToSend = JSON.parse(xmlhttp.response);
                                  }
                                  catch (err) {
                                  console.log('Err!');
                                  console.log(err.message);
                }
                                    createDataList();
                                    populateDataList(dataToSend);
                                    console.log('done');

                                } else if (xmlhttp.status == 400) {
                                    console.log('There was an error 400');
                                } else {
                                    console.log('something else other than 200 was returned');
                                }
                            }
                        };

                        xmlhttp.open('POST', 'http://howtodoonlinepricing.com/shopify/dev/validate.php', true);
                        xmlhttp.send(suburbSearch.value);

                    }

                } 

            }
        }

        // Vanilla JavaScript RegEx (Trim Leading and Trailing)
        function trimWithjQuery(str){
         return str.replace(/(^\s+|\s+$)/g,'');
        }


        function populateFields() {
            var suburb = document.getElementById('checkout_shipping_address_address2');
            var addressToSplit = suburb.value;
            var arr = addressToSplit.split(',');
            var city = document.getElementById('checkout_shipping_address_city');
            var postal = document.getElementById('checkout_shipping_address_zip');
            suburb.value = trimWithjQuery(arr[0]);
            city.value = trimWithjQuery(arr[1]);
            postal.value = trimWithjQuery(arr[2]);
            //Disable fields
            if((city.getAttribute('readonly')==false || city.getAttribute('readonly') == null) && (postal.getAttribute('readonly')==false || postal.getAttribute('readonly') == null)){
              city.setAttribute('readonly','true');
              postal.setAttribute('readonly','true');
            }

        }

        function populateDataList(dataToPopulate) {
            var dataList = document.getElementById("autocomplete-results");
            //Clear the list
            dataList.innerHTML = "";
            var formattedAddress;
            try{
            for (var i = 0; i < dataToPopulate.length; i++) {
                formattedAddress = dataToPopulate[i]['Addr3'] + ', ' + dataToPopulate[i]['Addr4'] + ', ' + dataToPopulate[i]['Addr5'] + ', ' + dataToPopulate[i]['Country'];
                poValue = formattedAddress;
                var option = document.createElement('option');
                option.value = poValue;
                option.text = formattedAddress;
                dataList.appendChild(option);
            }
          }
          catch(err){
            console.log('Err!');
            console.log(err.message);
          }

        }

        function createDataList() {;
            if (!document.getElementById('autocomplete-results')) {
                var currentNode = document.querySelector("#checkout_shipping_address_address2");
                var nodeToCreate = document.createElement("datalist");

                nodeToCreate.id = "autocomplete-results";
                currentNode.setAttribute('list', 'autocomplete-results');
                currentNode.parentNode.after(nodeToCreate, currentNode.previousSibling);
            }


        }
    }